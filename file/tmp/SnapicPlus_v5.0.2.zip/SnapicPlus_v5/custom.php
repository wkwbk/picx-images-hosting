<?php

/**
 * 新增自定义函数，请在当前 custom.php 文件进行，请自行研究！
 * 提示：本项设置属于个人行为，且违反购买协议（勿自行修改代码）之约定，作者不对此操作导致的状况，提供售后服务和技术支持，请知悉！
 * 注意：请勿在当前 custom.php 文件中，使用 Typecho 内置函数 themeConfig(), themeInit(), themeFields()
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit; error_reporting(E_ERROR | E_PARSE);

/**
 * 示例：将图片、视频、音频的原始链接，替换为新的链接
 * 场景：当使用第三方服务器（如：图床）存储图片、视频、音频资源时，对原始链接进行批量替换
 * 使用：根据情况配置原始链接和新的链接，可以添加多条一对一替换的链接数组
 * 重要：启用链接替换前，请确保存储在第三方服务器（如：图床）的图片、视频、音频资源，存在且路径正确
 */

function radvLqNZEkdQISzPTTU($BhJcvKx) {

	/**
	 * 根据情况配置
	 */

	$DtBYGrw = [
		'https://www.example.com' => 'https://cdn.example.com', // 将原始链接替换为新的链接，请自定义

		// 新增更多需要替换的链接
	];

    $cRbaSHI = false; // 为 true 则开启替换功能，为 false 则关闭，请自定义

	/**
	 * 以下勿动
	 */

	if ($cRbaSHI) {

		foreach ($DtBYGrw as $IynBWeK => $FYfpXdo) {
			$BhJcvKx = str_replace($IynBWeK, $FYfpXdo, $BhJcvKx);
		}

		$BhJcvKx = preg_replace_callback(GqJIVeBtDN()['WMDgXnForOqBC'], function($omQyZhA) use ($DtBYGrw) {
			foreach ($DtBYGrw as $IynBWeK => $FYfpXdo) {
				$omQyZhA[0] = str_replace($IynBWeK, $FYfpXdo, $omQyZhA[0]);
			}

			return $omQyZhA[0];
		}, $BhJcvKx);

		$BhJcvKx = preg_replace_callback(GqJIVeBtDN()['wtUNLjpDntsvPWg'], function($omQyZhA) use ($DtBYGrw) {
			foreach ($DtBYGrw as $IynBWeK => $FYfpXdo) {
				$omQyZhA[0] = str_replace($IynBWeK, $FYfpXdo, $omQyZhA[0]);
			}

			return $omQyZhA[0];
		}, $BhJcvKx);
	}

	return $BhJcvKx;

}
